
# GPL license notice

#<This program processes the raw data from Camerer et al. (2018) into "data_processed.csv">
#Copyright (C) <2024>  <Ryan Gray>

#This program is free software: you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation, either version 3 of the License, or
#(at your option) any later version.

#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.

#You should have received a copy of the GNU General Public License
#along with this program.  If not, see <https://www.gnu.org/licenses/>.

# Read in data ------------------------------------------------------------
library(tidyverse)
stats <- read.csv("data/TestStats2_wide.csv")

# Load user defined functions
source("Functions_onlyV2.R")
# convert df2 columns from character to numeric
stats <- mutate(stats, 
                df2_os = as.numeric(stats$df2_os),
                df2_rs1 = as.numeric(stats$df2_rs1),
                df2_rs2 = as.numeric(stats$df2_rs2)
)

# original study ----------------------------------------------------------

# filter test statistics

zstats_os <- filter(stats, type_os == 1)

tstats_os <- filter(stats, type_os == 2)

Fstats_os <- filter(stats, type_os == 3)

chi2stats_os <- filter(stats, type_os == 4)

# Convert F to t statistic and merge with t stats
Fstats_os$stat_os <- Fstats_os %>% select(stat_os) %>% apply(2, F2t)

t_os <- rbind(tstats_os, Fstats_os)

# Convert chi2 to z statistics and merge with z stats
chi2stats_os$stat_os <- chi2stats_os %>% select(stat_os) %>% apply(2, chi2z)

z_os <- rbind(zstats_os, chi2stats_os)

# calculate r from t statistics

tr_os <- mapply(t2r, t_os$stat_os, t_os$df2_os)

# calculate r from z statistics

zr_os <- mapply(z2r, z_os$stat_os, z_os$n_os)


# calculate p values for r (t statistics)

tp_os <- mapply(tpvalues, t_os$stat_os, t_os$df2_os)

# calculate p values for r (z statistics)

zp_os <- mapply(zpvalues, z_os$stat_os)

# Add columns for r_os and p_os and merge z and t statistic data.
t_os <- mutate(t_os, r_os = tr_os, p_os = tp_os)

z_os <- mutate(z_os, r_os = zr_os, p_os = zp_os)

stats_os <- rbind(t_os, z_os)

# write stats_os to csv to manually change sign of r (only ran once so manual changes stay)

#write.csv(stats_os, 
         #"data\\rstats_os.csv", 
          #row.names = FALSE)

stats_osv2 <- read.csv("data\\rstats_os.csv")

# Calculate 95% confidence intervals

l95os <- mapply(rlowr, stats_osv2$r_os, 0.05, stats_osv2$n_os)

u95os <- mapply(rupr, stats_osv2$r_os, 0.05, stats_osv2$n_os)
# calculate 90% confidence intervals

l90os <- mapply(rlowr, stats_osv2$r_os, 0.10, stats_osv2$n_os)

u90os <- mapply(rupr, stats_osv2$r_os, 0.10, stats_osv2$n_os)

# Create columns for confidence intervals

stats_os_CIs <- mutate(stats_osv2, r95l_os = l95os, r95u_os = u95os, r90l_os = l90os, r90u_os = u90os)


# Replication round 1 -----------------------------------------------------

# filter test statistics

zstats_rs1 <- filter(stats, type_rs1 == 1)

tstats_rs1 <- filter(stats, type_rs1 == 2)

Fstats_rs1 <- filter(stats, type_rs1 == 3)

chi2stats_rs1 <- filter(stats, type_rs1 == 4)

# Convert F to t statistic and merge with t stats
Fstats_rs1$stat_rs1 <- Fstats_rs1 %>% select(stat_rs1) %>% apply(2, F2t)

t_rs1 <- rbind(tstats_rs1, Fstats_rs1)

# Convert chi2 to z statistics and merge with z stats
chi2stats_rs1$stat_rs1 <- chi2stats_rs1 %>% select(stat_rs1) %>% apply(2, chi2z)

z_rs1 <- rbind(zstats_rs1, chi2stats_rs1)

# calculate r from t statistics

tr_rs1 <- mapply(t2r, t_rs1$stat_rs1, t_rs1$df2_rs1)

# calculate r from z statistics

zr_rs1 <- mapply(z2r, z_rs1$stat_rs1, z_rs1$n_rs1)

# calculate p values for r (t statistics)

tp_rs1 <- mapply(tpvalues, t_rs1$stat_rs1, t_rs1$df2_rs1)

# calculate p values for r (z statistics)

zp_rs1 <- mapply(zpvalues, z_rs1$stat_rs1)

# Add columns for r_rs1 and p_rs1 and merge z and t statistic data.
t_rs1 <- mutate(t_rs1, r_rs1 = tr_rs1, p_rs1 = tp_rs1)

z_rs1 <- mutate(z_rs1, r_rs1 = zr_rs1, p_rs1 = zp_rs1)

stats_rs1 <- rbind(t_rs1, z_rs1)

# write stats_rs1 to csv to manually change sign of r (only ran once so manual changes stay)

#write.csv(stats_rs1, 
         # "data\\rstats_rs1.csv", 
         # row.names = FALSE)

stats_rs1v2 <- read.csv("data\\rstats_rs1.csv")

# Calculate 95% confidence intervals

l95rs1 <- mapply(rlowr, stats_rs1v2$r_rs1, 0.05, stats_rs1v2$n_rs1)

u95rs1 <- mapply(rupr, stats_rs1v2$r_rs1, 0.05, stats_rs1v2$n_rs1)
# calculate 90% confidence intervals

l90rs1 <- mapply(rlowr, stats_rs1v2$r_rs1, 0.10, stats_rs1v2$n_rs1)

u90rs1 <- mapply(rupr, stats_rs1v2$r_rs1, 0.10, stats_rs1v2$n_rs1)

# Create columns for confidence intervals

stats_rs1_CIs <- mutate(stats_rs1v2, r95l_rs1 = l95rs1, r95u_rs1 = u95rs1, r90l_rs1 = l90rs1, r90u_rs1 = u90rs1)


# Replication Round 2 -----------------------------------------------------

# filter test statistics

zstats_rs2 <- filter(stats, type_rs2 == 1)

tstats_rs2 <- filter(stats, type_rs2 == 2)

Fstats_rs2 <- filter(stats, type_rs2 == 3)

chi2stats_rs2 <- filter(stats, type_rs2 == 4)

# Convert F to t statistic and merge with t stats
Fstats_rs2$stat_rs2 <- Fstats_rs2 %>% select(stat_rs2) %>% apply(2, F2t)

t_rs2 <- rbind(tstats_rs2, Fstats_rs2)

# Convert chi2 to z statistics and merge with z stats
chi2stats_rs2$stat_rs2 <- chi2stats_rs2 %>% select(stat_rs2) %>% apply(2, chi2z)

z_rs2 <- rbind(zstats_rs2, chi2stats_rs2)

# calculate r from t statistics

tr_rs2 <- mapply(t2r, t_rs2$stat_rs2, t_rs2$df2_rs2)

# calculate r from z statistics

zr_rs2 <- mapply(z2r, z_rs2$stat_rs2, z_rs2$n_rs2)

# calculate p values for r (t statistics)

tp_rs2 <- mapply(tpvalues, t_rs2$stat_rs2, t_rs2$df2_rs2)

# calculate p values for r (z statistics)

zp_rs2 <- mapply(zpvalues, z_rs2$stat_rs2)

# Add columns for r_rs2 and p_rs2 and merge z and t statistic data.
t_rs2 <- mutate(t_rs2, r_rs2 = tr_rs2, p_rs2 = tp_rs2)

z_rs2 <- mutate(z_rs2, r_rs2 = zr_rs2, p_rs2 = zp_rs2)

stats_rs2 <- rbind(t_rs2, z_rs2)

# write stats_rs2 to csv to manually change sign of r (only ran once so manual changes stay)

#write.csv(stats_rs2, 
         # "data\\rstats_rs2.csv", 
         # row.names = FALSE)

stats_rs2v2 <- read.csv("data\\rstats_rs2.csv")

# Calculate 95% confidence intervals

l95rs2 <- mapply(rlowr, stats_rs2v2$r_rs2, 0.05, stats_rs2v2$n_rs2)

u95rs2 <- mapply(rupr, stats_rs2v2$r_rs2, 0.05, stats_rs2v2$n_rs2)
# calculate 90% confidence intervals

l90rs2 <- mapply(rlowr, stats_rs2v2$r_rs2, 0.10, stats_rs2v2$n_rs2)

u90rs2 <- mapply(rupr, stats_rs2v2$r_rs2, 0.10, stats_rs2v2$n_rs2)

# Create columns for confidence intervals

stats_rs2_CIs <- mutate(stats_rs2v2, r95l_rs2 = l95rs2, r95u_rs2 = u95rs2, r90l_rs2 = l90rs2, r90u_rs2 = u90rs2)


# Merge all data together -------------------------------------------------

# select relevant columns in each data

data_os <- stats_os_CIs %>% select(study, n_os, r_os, p_os, r95l_os, r95u_os, r90l_os, r90u_os)

data_rs1 <- stats_rs1_CIs %>% select(study, n_rs1, r_rs1, p_rs1, r95l_rs1, r95u_rs1, r90l_rs1, r90u_rs1)

data_rs2 <- stats_rs2_CIs %>% select(study, n_rs2, r_rs2, p_rs2, r95l_rs2, r95u_rs2, r90l_rs2, r90u_rs2)

# left join original study and replication 1 results

data_cmb <- left_join(data_os,
                   data_rs1)
# left join replication 2 data to above combined data

data_cmb2 <- left_join(data_cmb,
                       data_rs2)
# Fixed effects meta-analytic effect size ---------------------------------

# meta effect rs1

metars1 <- mapply(metaeffect, r_os = data_cmb2$r_os, n_os = data_cmb2$n_os, r_rs = data_cmb2$r_rs1, n_rs = data_cmb2$n_rs1)

# 95% confidence intervals around meta effect size rs1

rm95lrs1 <- mapply(rlowr, metars1, 0.05, n = data_cmb2$n_os + data_cmb2$n_rs1 - 3)

rm95urs1 <- mapply(rupr, metars1, 0.05, n = data_cmb2$n_os + data_cmb2$n_rs1 - 3)

# meta rs1 p value

meta_rs1p <- mapply(metapod, r_os = data_cmb2$r_os, n_os = data_cmb2$n_os, r_rs = data_cmb2$r_rs1, n_rs = data_cmb2$n_rs1)

# meta effect rs2

metars2 <- mapply(metaeffect, r_os = data_cmb2$r_os, n_os = data_cmb2$n_os, r_rs = data_cmb2$r_rs2, n_rs = data_cmb2$n_rs2)

# 95% confidence intervals around meta effect size rs2

rm95lrs2 <- mapply(rlowr, metars2, 0.05, n = data_cmb2$n_os + data_cmb2$n_rs2 - 3)

rm95urs2 <- mapply(rupr, metars2, 0.05, n = data_cmb2$n_os + data_cmb2$n_rs2 - 3)

# meta rs2 p value

meta_rs2p <- mapply(metapod, r_os = data_cmb2$r_os, n_os = data_cmb2$n_os, r_rs = data_cmb2$r_rs2, n_rs = data_cmb2$n_rs2)

# join to rest of data

data_meta <- mutate(data_cmb2,
                    rm_rs1 = metars1,
                    rm95l_rs1 = rm95lrs1,
                    rm95u_rs1 = rm95urs1,
                    rm_p_rs1 = meta_rs1p, 
                    rm_rs2 = metars2,
                    rm95l_rs2 = rm95lrs2,
                    rm95u_rs2 = rm95urs2,
                    rm_p_rs2 = meta_rs2p)


# Small telescopes Approach (original study only) -----------------------------------------------

# calculate small effect of original study

smalleffect <- mapply(smalleffects, n_os = data_meta$n_os, pow = 1/3, p = 0.05)

# Add column for small effects 

data_smalleffect <- mutate(data_meta, r33_os = smalleffect)


# Calculate Relative Effect Sizes -----------------------------------------

# rr --------------

# rs1 rr and 90/95% confidence intervals

rs1rr <- data_smalleffect$r_rs1 / data_smalleffect$r_os

rr95lrs1 <- data_smalleffect$r95l_rs1 / data_smalleffect$r_os

rr95urs1 <- data_smalleffect$r95u_rs1 / data_smalleffect$r_os

rr90lrs1 <- data_smalleffect$r90l_rs1 / data_smalleffect$r_os

rr90urs1 <- data_smalleffect$r90u_rs1 / data_smalleffect$r_os

# rs2 rr and 90/95% confidence intervals

rs2rr <- data_smalleffect$r_rs2 / data_smalleffect$r_os

rr95lrs2 <- data_smalleffect$r95l_rs2 / data_smalleffect$r_os

rr95urs2 <- data_smalleffect$r95u_rs2 / data_smalleffect$r_os

rr90lrs2 <- data_smalleffect$r90l_rs2 / data_smalleffect$r_os

rr90urs2 <- data_smalleffect$r90u_rs2 / data_smalleffect$r_os
# rrm -------------

# rs1 rrm and 95% confidence intervals

rs1rrm <- data_smalleffect$rm_rs1 / data_smalleffect$r_os

rrm95lrs1 <- data_smalleffect$rm95l_rs1 / data_smalleffect$r_os

rrm95urs1 <- data_smalleffect$rm95u_rs1 / data_smalleffect$r_os

# rs2 rrm and 95% confidence intervals

rs2rrm <- data_smalleffect$rm_rs2 / data_smalleffect$r_os

rrm95lrs2 <- data_smalleffect$rm95l_rs2 / data_smalleffect$r_os

rrm95urs2 <- data_smalleffect$rm95u_rs2 / data_smalleffect$r_os

# rr33 for original study only

rr33 <- data_smalleffect$r33_os / data_smalleffect$r_os

# Add columns for calculated statistics above

data_rr <- mutate(data_smalleffect,
               rr33_os = rr33,
               rr_rs1 = rs1rr,
               rr95l_rs1 = rr95lrs1,
               rr95u_rs1 = rr95urs1,
               rr90l_rs1 = rr90lrs1,
               rr90u_rs1 = rr90urs1,
               rr_rs2 = rs2rr,
               rr95l_rs2 = rr95lrs2,
               rr95u_rs2 = rr95urs2,
               rr90l_rs2 = rr90lrs2,
               rr90u_rs2 = rr90urs2,
               rrm_rs1 = rs1rrm,
               rrm95l_rs1 = rrm95lrs1,
               rrm95u_rs1 = rrm95urs1,
               rrm_rs2 = rs2rrm,
               rrm95l_rs2 = rrm95lrs2,
               rrm95u_rs2 = rrm95urs2)


# Prediction intervals ----------------------------------------------------

# standard effect size (r) rs1 

rp95lrs1 <- mapply(predlwr, data_rr$r_os, data_rr$n_os, data_rr$n_rs1, 0.05)

rp95urs1 <- mapply(predupr, data_rr$r_os, data_rr$n_os, data_rr$n_rs1, 0.05)

# standard effect size (r) rs2

rp95lrs2 <- mapply(predlwr, data_rr$r_os, data_rr$n_os, data_rr$n_rs2, 0.05)

rp95urs2 <- mapply(predupr, data_rr$r_os, data_rr$n_os, data_rr$n_rs2, 0.05)

# Relative standard effect size (rr) rs1 

rrp95lrs1 <- rp95lrs1 / data_rr$r_os

rrp95urs1 <- rp95urs1 / data_rr$r_os

# Relative standard effect size (rr) rs2 

rrp95lrs2 <- rp95lrs2 / data_rr$r_os

rrp95urs2 <- rp95urs2 / data_rr$r_os

# Add columns for prediction intervals calculated above.

data_preds <- mutate(data_rr, 
                     rp95l_rs1 = rp95lrs1,
                     rp95u_rs1 = rp95urs1,
                     rrp95l_rs1 = rrp95lrs1,
                     rrp95u_rs1 = rrp95urs1,
                     rp95l_rs2 = rp95lrs2,
                     rp95u_rs2 = rp95urs2,
                     rrp95l_rs2 = rrp95lrs2,
                     rrp95u_rs2 = rrp95urs2)


# Replication indicators --------------------------------------------------

data_final <- data_preds %>%
  mutate(rep_sr_rs1 = ifelse(p_rs1 < 0.05, 1, 0), # significant effect in same direction as original study
         rep_sr_rs2 = ifelse(p_rs2 < 0.05, 1, 0), 
         rep_mr_rs1 = ifelse(rm95l_rs1 > 0 & rm_p_rs1 < 0.05, 1, 0), # meta effect estimate significantly different from zero
         rep_mr_rs2 = ifelse(rm95l_rs2 > 0 & rm_p_rs2 < 0.05, 1, 0),
         rep_st_rs1 = ifelse(r90u_rs1 > r33_os, 1, 0), # replication effect not significantly smaller than small effect
         rep_st_rs2 = ifelse(r90u_rs2 > r33_os, 1, 0),
         rep_pi_rs1 = ifelse(r_rs1 > rp95l_rs1 & r_rs1 < rp95u_rs1, 1, 0), # replication effect size within 95% prediction interval
         rep_pi_rs2 = ifelse(r_rs2 > rp95l_rs2 & r_rs2 < rp95u_rs2, 1, 0)
)

# write to csv file -------------------------------------------------------

write.csv(data_final, 
          "data\\data_processed.csv", 
          row.names = FALSE)

