# GPL license notice

#<This program contains the functions created to calculate the statistics in "Data_processing.R">
    #Copyright (C) <2024>  <Ryan Gray>

    #This program is free software: you can redistribute it and/or modify
    #it under the terms of the GNU General Public License as published by
    #the Free Software Foundation, either version 3 of the License, or
    #(at your option) any later version.

    #This program is distributed in the hope that it will be useful,
    #but WITHOUT ANY WARRANTY; without even the implied warranty of
    #MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    #GNU General Public License for more details.

    #You should have received a copy of the GNU General Public License
    #along with this program.  If not, see <https://www.gnu.org/licenses/>.



# Convert test statistics -------------------------------------------------

# Convert F to t statistic

F2t <- function(fstat) sqrt(abs(fstat)) * sign(fstat)

# Convert Chi^2 to z statistic

chi2z <- function(chisqstat) sqrt(abs(chisqstat)) * sign(chisqstat)

# Convert z statistic to r

z2r <- function(z, n) tanh(z * sqrt(1/(n-3)))

# Convert t statistic to r

t2r <- function(tstat,df2) sqrt(tstat^2/(tstat^2+df2))

# Calculate P values for r ------------------------------------------------

# z stat function

zpvalues <- function(z) pnorm(-abs(z)) * 2
# t stat function

tpvalues <- function(tstat, df2) 2 * pt(abs(tstat), df = df2, lower.tail = FALSE)

# Confidence intervals for r functions ------------------------------------

rlowr <- function(r, p, n) tanh(atanh(r) - qnorm(1 - (p/2)) * sqrt(1/(n - 3)))

rupr <- function(r, p, n) tanh(atanh(r) + qnorm(1 - (p/2)) * sqrt(1/(n - 3)))


# Prediction intervals around r -------------------------------------------

predlwr <- function(r_os, n_os, n_rs, p)  tanh(atanh(r_os) - qnorm(1 - (p/2)) * sqrt(1/(n_os - 3) + 1/(n_rs - 3)))

predupr <- function(r_os, n_os, n_rs, p)  tanh(atanh(r_os) + qnorm(1 - (p/2)) * sqrt(1/(n_os - 3) + 1/(n_rs - 3)))


# Fixed effects weighted meta result --------------------------------------

metaeffect <- function (r_os, n_os, r_rs, n_rs
) {
w_os <- n_os - 3
w_rs <- n_rs - 3
z_os <- atanh(r_os)
z_rs <- atanh(r_rs)
z_meta <- (w_os * z_os + w_rs * z_rs) / (w_os + w_rs)
r_meta <- tanh(z_meta)
return(r_meta)
}

# p value for meta effect size

metapod <- function (r_os, n_os, r_rs, n_rs
) {
  w_os <- n_os - 3
  w_rs <- n_rs - 3
  z_os <- atanh(r_os)
  z_rs <- atanh(r_rs)
  z_meta <- (w_os * z_os + w_rs * z_rs) / (w_os + w_rs)
  r_meta <- tanh(z_meta)
  n_meta <- n_os + n_rs - 3
  t_meta <- r_meta / sqrt((1 - r_meta^2) / (n_meta - 2))
  p_meta <- 2 * pt(df = n_meta - 2, t_meta, lower.tail = FALSE)
  return(p_meta)
}

# small telescopes approach -----------------------------------------------

# Calculate TempPow

temppow <- function(r, n, p
) {
ttt <- qt(df = n - 2, 1 - p/2)
r <- abs(r)
rc <- sqrt(ttt^2 / (ttt^2 + n - 2))
zrc <- atanh(rc)
zr <- atanh(r) + r / (2 * (n - 1))
pow <- pnorm((zr - zrc) * sqrt(n - 3)) +
  pnorm((-zr - zrc) * sqrt(n - 3))
return(pow)
}

# small tesescopes

smalleffects <- function(n_os, pow, p
) {
temp_r <- 0
temp_pow <- 0
while(abs(pow - temp_pow) >= 0.001 & temp_r < 1) {
      studypower <- mapply(temppow, temp_r, n_os, p)
      temp_pow <- studypower
      temp_r <- temp_r + 0.0001
      print("temporary power: temp_pow")
      print("temporary r: temp_r")
      }
r_se <- temp_r
return(r_se)
}


# Statistical power of replication study ----------------------------------

# Original z statistical power
eosz <- function(e, r, n) { 
re <- atanh(e / 100 * r) * sqrt(n - 3)
return(re)
}
# Original t statistical power
eost <- function(e, r, n) {
re <- sign(e / 100 * r) * ((1 / (e / 100 * r)^2 - 1) / n- 2)^(-0.5)
return(re)
}
# replication z statistical power

ze <- function(re, n, n_rs) { 
  1 - pnorm(qnorm(0.975) - re / sqrt(n) * sqrt(n_rs))
}

# replication t statistical power

te <- function(re, n, n_rs) { 
  1 - t(n_rs - 2, invt(n_rs, 0.975) - re / sqrt(n) * sqrt(n_rs))
}


# Replication sample sizes to detect p% of original effect size -----------




